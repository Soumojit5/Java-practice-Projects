package com.infy.ekart.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.infy.ekart.entity.Card;



public interface CardRepository extends CrudRepository<Card, Integer> {
	
	// add methods if required
	List<Card> findByCustomerEmail(String customerEmail);
	Optional<Card> findByCardID(Integer cardID);
	List<Card>  findByCustomerEmailAndCardType(String customerEmail,String cardType);
}
